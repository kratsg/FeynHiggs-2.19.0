{dg[hhSbSb, 3, 3, 2, 2] -> (2*dhb1*g[hhSbSb, 3, 3, 2, 2])/hb, {}}
