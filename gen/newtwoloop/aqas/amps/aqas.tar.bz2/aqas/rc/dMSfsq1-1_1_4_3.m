{dMSfsq1[1, 1, 4, 3] -> (Abs[USf[1, 2, 4, 3]]^2*dMSfsq1[2, 2, 4, 3] + 
    (Abs[USf[1, 1, 4, 3]]^2 - Abs[USf[1, 2, 4, 3]]^2)*dMsq11Sf1[4, 3] + 
    2*Re[dMsq12Sf1[4, 3]*USf[1, 1, 4, 3]*USfC[1, 2, 4, 3]])/
   Abs[USf[1, 1, 4, 3]]^2, {}}
