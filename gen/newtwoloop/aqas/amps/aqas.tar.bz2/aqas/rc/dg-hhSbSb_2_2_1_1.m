{dg[hhSbSb, 2, 2, 1, 1] -> (2*dhb1*g[hhSbSb, 2, 2, 1, 1])/hb, {}}
