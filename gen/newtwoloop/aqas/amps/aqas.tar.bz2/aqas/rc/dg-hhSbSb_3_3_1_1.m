{dg[hhSbSb, 3, 3, 1, 1] -> (2*dhb1*g[hhSbSb, 3, 3, 1, 1])/hb, {}}
