{dMSfsq1[1, 2, 4, 3] -> 
  -((((-dMSfsq1[1, 1, 4, 3] + dMSfsq1[2, 2, 4, 3])*USf[1, 1, 4, 3] + 
       Conjugate[dMsq12Sf1[4, 3]]*USf[1, 2, 4, 3])*USfC[2, 1, 4, 3] - 
     dMsq12Sf1[4, 3]*USf[1, 1, 4, 3]*USfC[2, 2, 4, 3])/
    (Abs[USf[1, 1, 4, 3]]^2 - Abs[USf[1, 2, 4, 3]]^2)), {}}
