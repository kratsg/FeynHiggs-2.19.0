{dg[hSbSb, 1, 2, 2] -> 
  -((dhb1*((MUEC*SB - CB*Af[4, 3, 3])*USf[2, 2, 4, 3]*USfC[2, 1, 4, 3] + 
       (MUE*SB - CB*AfC[4, 3, 3])*USf[2, 1, 4, 3]*USfC[2, 2, 4, 3] - 
       2*CB*MB*(USf[2, 1, 4, 3]*USfC[2, 1, 4, 3] + USf[2, 2, 4, 3]*
          USfC[2, 2, 4, 3])))/Sqrt[2]) + 
   CB*hb*((dAf1[4, 3, 3]*USf[2, 2, 4, 3]*USfC[2, 1, 4, 3] + 
       Conjugate[dAf1[4, 3, 3]]*USf[2, 1, 4, 3]*USfC[2, 2, 4, 3])/Sqrt[2] + 
     Sqrt[2]*dMf1[4, 3]*(USf[2, 1, 4, 3]*USfC[2, 1, 4, 3] + 
       USf[2, 2, 4, 3]*USfC[2, 2, 4, 3])), {}}
