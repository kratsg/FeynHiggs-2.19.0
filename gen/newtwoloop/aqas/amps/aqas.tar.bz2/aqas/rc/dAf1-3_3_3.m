{dAf1[3, 3, 3] -> ((MUEC/TB - Af[3, 3, 3])*dMf1[3, 3] + 
    ((dMSfsq1[1, 1, 3, 3] - dMSfsq1[2, 2, 3, 3])*USf[1, 1, 3, 3] + 
      dMSfsq1[1, 2, 3, 3]*USf[2, 1, 3, 3])*USfC[1, 2, 3, 3] + 
    Conjugate[dMSfsq1[1, 2, 3, 3]]*USf[1, 1, 3, 3]*USfC[2, 2, 3, 3])/MT, {}}
