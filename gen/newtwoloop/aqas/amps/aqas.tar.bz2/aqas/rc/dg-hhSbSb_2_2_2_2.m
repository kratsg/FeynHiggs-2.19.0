{dg[hhSbSb, 2, 2, 2, 2] -> (2*dhb1*g[hhSbSb, 2, 2, 2, 2])/hb, {}}
